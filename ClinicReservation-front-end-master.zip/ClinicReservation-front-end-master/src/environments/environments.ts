export const environment = {
  production: false,
  apiUrl: 'https://clinic-reservation-back-git-amrmahmoud33-dev.apps.sandbox-m2.ll9k.p1.openshiftapps.com/api/v1',
  auth: 'api/v1/auth',
};
